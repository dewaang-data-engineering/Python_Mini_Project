# Python_Mini_Project
This is regex and python mini project.
